package com.example.glasslauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

data class AppItem(val label: String, val pkg: String, val icon: Bitmap, val intent: Intent)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BackHandler { /* stay on home */ }
            val apps = remember { loadApps() }
            Home(apps) { startActivity(it.intent) }
        }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        fun query(cat: String) = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(cat), PackageManager.MATCH_ALL
        )
        val list = query(Intent.CATEGORY_LEANBACK_LAUNCHER).ifEmpty { query(Intent.CATEGORY_LAUNCHER) }
        return list
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val pkg = it.activityInfo.packageName
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    pkg = pkg,
                    icon = (it.activityInfo.loadBanner(pm) ?: it.loadIcon(pm)).toBitmap(256, 256),
                    intent = pm.getLeanbackLaunchIntentForPackage(pkg)
                        ?: pm.getLaunchIntentForPackage(pkg)!!
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}

@Composable
fun Home(apps: List<AppItem>, onLaunch: (AppItem) -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF0B0F1A), Color(0xFF151B2E), Color(0xFF0A0A12)))
        )
    ) {
        // Soft blurred light blobs: gives the glass something to refract
        Box(
            Modifier.offset(80.dp, 120.dp).size(420.dp).blur(140.dp)
                .background(Color(0x663A6BFF), CircleShape)
        )
        Box(
            Modifier.align(Alignment.BottomEnd).offset((-60).dp, (-40).dp).size(360.dp).blur(140.dp)
                .background(Color(0x55B05CFF), CircleShape)
        )

        Column(Modifier.fillMaxSize().padding(horizontal = 64.dp, vertical = 48.dp)) {
            Clock()
            Spacer(Modifier.weight(1f))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                contentPadding = PaddingValues(vertical = 24.dp)
            ) {
                items(apps, key = { it.pkg }) { GlassCard(it) { onLaunch(it) } }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
fun Clock() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    Column {
        BasicText(
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
            style = TextStyle(Color.White, 64.sp, FontWeight.Light)
        )
        BasicText(
            SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
            style = TextStyle(Color(0xAAFFFFFF), 20.sp)
        )
    }
}

@Composable
fun GlassCard(app: AppItem, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.12f else 1f, label = "scale")
    val shape = RoundedCornerShape(28.dp)

    Column(
        Modifier
            .width(180.dp)
            .scale(scale)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    if (focused) listOf(Color(0x40FFFFFF), Color(0x18FFFFFF))
                    else listOf(Color(0x1FFFFFFF), Color(0x0AFFFFFF))
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    if (focused) listOf(Color(0xCCFFFFFF), Color(0x33FFFFFF))
                    else listOf(Color(0x44FFFFFF), Color(0x11FFFFFF))
                ),
                shape
            )
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(app.icon.asImageBitmap(), app.label, Modifier.size(96.dp).clip(RoundedCornerShape(18.dp)))
        Spacer(Modifier.height(14.dp))
        BasicText(
            app.label,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = TextStyle(
                if (focused) Color.White else Color(0xBBFFFFFF),
                16.sp, textAlign = TextAlign.Center
            )
        )
    }
}
